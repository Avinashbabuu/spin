# helper.py content
