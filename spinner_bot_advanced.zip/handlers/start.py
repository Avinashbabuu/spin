# start.py content
